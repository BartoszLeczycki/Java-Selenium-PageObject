import io.github.bonigarcia.wdm.WebDriverManager;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import page.ContactUs;
import page.SignIn;
import page.TopMenu;

public class Main {
    private static WebDriver driver;
    private static TopMenu topMenu ;
    private static ContactUs contactUs;
    private static SignIn signIn;

@BeforeAll
    public static void BeforeAll(){
    WebDriverManager.chromedriver().setup();
    driver = new ChromeDriver();
    topMenu = new TopMenu(driver);
    contactUs = new ContactUs(driver);
    signIn = new SignIn(driver);
    }

@BeforeEach
    public void BeforeEach(){
    driver.get("http://automationpractice.com");
    driver.manage().window().maximize();
}

@AfterAll
    public static void AfterAll(){
    driver.quit();
}


@Test
    public void CheckTitle(){
    System.out.println(driver.getTitle());
    Assertions.assertThat(driver.getTitle()).isEqualTo("My Store");
  }

  @Test
    public void CanNotSendContactUsMessageWithEmptyEmail(){
      topMenu.ClickOnContactUsButton();
      contactUs.ClickOnSendButton();
      Assertions.assertThat(contactUs.IsErrorAlertDisplayed()).isTrue();
  }

  @Test
    public void CanNotCreateAccountWithEmptyEmail(){
      topMenu.ClickOnSingInButton()
              .ClickOnCreateAnAccountButton();
      Assertions.assertThat(signIn.IsCreateAnAccountErrorDisplayed()).isTrue();
  }

  @Test
    public void SendContactUsMessgae(){
      topMenu.ClickOnContactUsButton()
               .SelectSubject(1)
               .EnterEmail()
               .EnterOrder()
               .EnterMessage()
               .ClickOnSendButton();

      Assertions.assertThat(contactUs.IsSuccessMessgaeDisplayed()).isTrue();
  }
}
