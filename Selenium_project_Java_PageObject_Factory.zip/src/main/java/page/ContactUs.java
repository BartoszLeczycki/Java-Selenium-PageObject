package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ContactUs extends PageObject{

    public ContactUs(WebDriver driver){
        super(driver);
    }

    @FindBy(id = "submitMessage") private WebElement sendButton;
    @FindBy(css = "div.alert") private WebElement errorAlert;
    @FindBy(id = "id_contact") private WebElement subjectContact;
    @FindBy(id = "email") private WebElement emailInput;
    @FindBy(id = "id_order") private WebElement orderInput;
    @FindBy(id = "message") private WebElement messageTextArea;
    @FindBy(css = "p.alert-success") private WebElement alertSucces;



    public ContactUs ClickOnSendButton(){
        sendButton.click();
        return this;
    }

    public WebElement GetErrorAlert(){
        return errorAlert;
    }

    public boolean IsErrorAlertDisplayed(){
        return GetErrorAlert().isDisplayed();
    }

    public ContactUs SelectSubject(int subjectNumber){
        new Select(subjectContact).selectByIndex(subjectNumber);
        return this;
    }

    public ContactUs EnterEmail(){
        emailInput.clear();
        emailInput.sendKeys("test@test.com");
        return this;
    }

    public ContactUs EnterOrder(){
        orderInput.clear();
        orderInput.sendKeys("123123");
        return this;
    }

    public ContactUs EnterMessage(){
        messageTextArea.clear();
        messageTextArea.sendKeys("Hello from message !!!");
        return this;
    }

    public boolean IsSuccessMessgaeDisplayed(){
        return alertSucces.isDisplayed();
    }
}
